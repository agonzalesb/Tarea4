
library(readr)
# seleccionamos los Datos_Churn.csv
df <- read_csv("datos/originales/Datos_Churn.csv")

table(df$ScoringCrediticio)
table(df$Pais)
table(df$Genero)
table(df$Edad)
table(df$IdCuenta)
table(df$BalanceCuenta)
table(df$CantidadProductos)
table(df$TarjetaCredito)
table(df$Activo)
table(df$SalarioEstimado)

df <- dplyr::select(df,-IdCliente,- Apellido)
names(df)
str(df)

table(is.na(df$DejaBanco))

df <- df[!is.na(df$DejaBanco),]

table(is.na(df$ScoringCrediticio))
table(is.na(df$Pais))
table(is.na(df$Genero))
table(is.na(df$Edad))
table(is.na(df$IdCuenta))
table(is.na(df$BalanceCuenta))
table(is.na(df$CantidadProductos))
table(is.na(df$TarjetaCredito))
table(is.na(df$Activo))
table(is.na(df$SalarioEstimado))

df <- df[!is.na(df$ScoringCrediticio),]
df <- df[!is.na(df$Pais),]
df <- df[!is.na(df$Genero),]
df <- df[!is.na(df$Edad),]
df <- df[!is.na(df$IdCuenta),]
df <- df[!is.na(df$BalanceCuenta),]
df <- df[!is.na(df$CantidadProductos),]
df <- df[!is.na(df$TarjetaCredito),]
df <- df[!is.na(df$Activo),]
df <- df[!is.na(df$SalarioEstimado),]

# unavez verificado el tipo de variable de cada campo generamos los archivos entrenamiento.rds y prueba.rds
#---------
prop.table(table(df$DejaBanco))

set.seed(123)

train <- caret::createDataPartition(y = df$DejaBanco, p = 0.7, list = FALSE, times = 1)
datos_train <- df[train, ]
datos_test  <- df[-train, ]

prop.table(table(datos_train$DejaBanco))
prop.table(table(datos_test$DejaBanco))


# guardamos los dos archivos 

# modificar la parte entre comillas con la ubicación de la carpeta real
write_rds(datos_train, "datos/limpios/entrenamiento.rds")
write_rds(datos_test, "datos/limpios/prueba.rds")

