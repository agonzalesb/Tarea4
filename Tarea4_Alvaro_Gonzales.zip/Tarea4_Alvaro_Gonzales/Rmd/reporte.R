#' ---
#' title: "reporte"
#' author: "Alvaro Alfonso Gonzales Bilbao"
#' date: "9/01/2021"
#' output: 
#'   html_document: 
#'     toc: yes
#'     code_folding: hide
#' ---
#' 
#' ## __Tarea Numero 4__
#' 
#' En la carpeta __/Rmd__ cree un llamado reporte.Rmd en donde va a presentar los
#' resultados de modelo de bosques, su matriz de confusion y precision por clase y una interpretacion de los resultados, recuerde que no vamos a generar el modelo en el Rmd, sino cargar el modelo que ya fue generado y se encuentra en la ruta /modelos/modelo bosques.rds
#' 
#' El Rmd debe cumplir los siguiente requerimientos:
#' 
#' *   Un indice que indique las secciones del documento.
#' *   Las tablas deben imprimirse de forma paginada.
#' *   El codigo debe poder ser ocultado.
#' *   Debe ser posible descargar el Rmd directamente desde el documento.
#' 
#' 
#' ## __Solucion__
#' 
#' Antes de realizar la matriz de confusion y precision cargamos el modelo y realizamos la prediccioncon los datos prueba.
#' 
## -----------------------------------------------------------------------------

prueba <- readr::read_rds("C:/Users/fcondorim/Desktop/R/datos/limpios/prueba.rds")
modelo <- readr::read_rds("C:/Users/fcondorim/Desktop/R/modelos/modelo_bosques.rds")


#' 
#' ### __Prediccion__
#' 
#' Realizamos la predicción:
#' 
## -----------------------------------------------------------------------------
library(randomForest)
bosques_pred <- predict(modelo, newdata = prueba)


#' 
#' ### __Pasos Previos__
#' 
#' Transformamos los anteriores resultados a variables comparables con el campo DejaBanco:
#' 
## -----------------------------------------------------------------------------

bosques_pred <- as.data.frame(bosques_pred)
transformar <- function(x){
  if (x>=0.5){
    return (1)
  }
  else{
    return(0)
  }
}

bosques_pred$DejaBanco_Pred <- rep(0, nrow(bosques_pred))
bosques_pred$DejaBanco_Pred <- sapply(bosques_pred$bosques_pred, transformar)
prueba_consolidado <- cbind(prueba, DejaBanco_Pred=bosques_pred$DejaBanco_Pred)


#' 
#' ### __Matriz de Confusion y Metricas__
#' 
#' Imprimimos la matriz de confusión y la precición por clase:
#' 
## -----------------------------------------------------------------------------
prueba_consolidado$DejaBanco <- factor( prueba_consolidado$DejaBanco) 
prueba_consolidado$DejaBanco_Pred<- factor( prueba_consolidado$DejaBanco_Pred)

conf <- table(prueba_consolidado$DejaBanco_Pred, prueba_consolidado$DejaBanco)

m.conf <- caret::confusionMatrix(conf)
print(m.conf)


#' ### __Interpretacion de la Matriz de Confusion y Metricas__
#' 
#' Interpretación de la matriz de confusión:
#' 
#' 
## -----------------------------------------------------------------------------
library(dplyr)
library(knitr)
library(kableExtra)


matriz_confusion <- m.conf$table

#Form.Basic <- c("striped", "bordered", "hover", "condensed", "responsive")
Form.Basic <- c("striped", "hold_position")

kable(matriz_confusion,caption = "Matriz de Confusion",  booktabs = T) %>% 
  kable_styling(latex_options = Form.Basic, full_width = F)


#' 
#' 
#' Interpretación de la precisión por clase:
#' 
#' 
## -----------------------------------------------------------------------------
library(dplyr)
library(knitr)
library(kableExtra)


matriz_confusion <- m.conf$byClass

#Form.Basic <- c("striped", "bordered", "hover", "condensed", "responsive")
Form.Basic <- c("striped", "hold_position")

kable(matriz_confusion,caption = "Metricas de la Matriz de Confusion",  booktabs = T) %>% 
  kable_styling(latex_options = Form.Basic, full_width = F)


#' 
#' 
#' Interpretación de los resultados:
#' 
#' 
#' ### __Descargar el RMD__
#' 
#' 
## -----------------------------------------------------------------------------
purl("reporte.Rmd", documentation = 2)

#' 
