## ---- dependencias --------
library(randomForest)
library(readr)

## ---- lectura_datos --------
entrenamiento <- read_rds("datos/limpios/entrenamiento.rds")


## ---- modelo_bosques --------
modelo <- randomForest(DejaBanco ~ ., data = entrenamiento)
modelo



## ---- guardar_modelo_bosques --------
write_rds(modelo,"modelos/modelo_bosques.rds")
